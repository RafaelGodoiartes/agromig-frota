$ErrorActionPreference = "Stop"
$projectRoot = $PSScriptRoot
$nodeExe = "C:\Users\Agromig\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
$wranglerCli = Join-Path $projectRoot "cloudflare-tools\node_modules\wrangler\bin\wrangler.js"
$accountId = "aa2969fc156ad9997b8fa7d37b5de2b2"

if (-not (Test-Path -LiteralPath $nodeExe)) { throw "Node.js não encontrado: $nodeExe" }
if (-not (Test-Path -LiteralPath $wranglerCli)) { throw "Wrangler não encontrado: $wranglerCli" }

Push-Location $projectRoot
$secureToken = $null
$tokenPtr = [IntPtr]::Zero
try {
    Write-Host "Digite o token novo da Cloudflare. O texto ficará oculto; não cole o token no chat."
    $secureToken = Read-Host "Token Cloudflare" -AsSecureString
    if ($secureToken.Length -lt 1) { throw "Nenhum token foi informado." }

    $tokenPtr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
    $env:CLOUDFLARE_API_TOKEN = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($tokenPtr)
    $env:CLOUDFLARE_ACCOUNT_ID = $accountId

    Write-Host "Compilando o site..."
    Push-Location (Join-Path $projectRoot "apps\web")
    try {
        & $nodeExe "tools\generate-llms.js"
        & $nodeExe "node_modules\vite\bin\vite.js" build --outDir "..\..\dist\apps\web"
        if ($LASTEXITCODE -ne 0) { throw "A compilação do site falhou (código $LASTEXITCODE)." }
    }
    finally {
        Pop-Location
    }

    Write-Host "Publicando o Worker agromig-frota..."
    & $nodeExe $wranglerCli deploy
    if ($LASTEXITCODE -ne 0) { throw "A publicação falhou (código $LASTEXITCODE). Confira a permissão Workers Scripts Edit do token." }

    Write-Host "Publicação concluída."
}
finally {
    if ($tokenPtr -ne [IntPtr]::Zero) {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($tokenPtr)
    }
    Remove-Item Env:CLOUDFLARE_API_TOKEN -ErrorAction SilentlyContinue
    Remove-Item Env:CLOUDFLARE_ACCOUNT_ID -ErrorAction SilentlyContinue
    if ($secureToken) { $secureToken.Dispose() }
    Pop-Location
}
