# Ativar leitura leve das planilhas

O Worker não deve mais baixar nem processar arquivos XLSX. O Apps Script agora entrega o conjunto de dados normalizado em JSON.

## 1. Atualize o Apps Script já usado pelo site

1. Abra o projeto Apps Script da integração Frota Agromig.
2. Abra `Code.gs` e substitua o conteúdo pelo arquivo `integracao_site_apps_script/Code.gs` deste workspace.
3. Salve. Mantenha a propriedade de script `WEBHOOK_SECRET` existente; não a envie no chat nem a altere.
4. Em **Implantar > Gerenciar implantações**, edite a implantação atual como **nova versão** e implante. Preserve a URL e a configuração de acesso atuais.

## 2. Publique o Worker

Depois da nova versão do Apps Script estar implantada, execute `publicar_cloudflare.ps1` na pasta deste projeto. Informe o token da Cloudflare somente no prompt oculto do PowerShell.

O `wrangler.jsonc` está configurado com `keep_vars: true`, para preservar as variáveis que já estejam definidas no painel da Cloudflare. O Worker depende de `GOOGLE_SHEETS_WEBHOOK_URL` e do segredo `GOOGLE_SHEETS_WEBHOOK_SECRET` já configurados no Worker.

## 3. Verifique

Abra o site e confirme que os dados carregam. Se a integração estiver configurada, a rota `GET /hcgi/api/fleet` deve retornar o JSON normalizado do Apps Script sem processar XLSX no Worker.
